const express = require('express');
const Task = require('../models/task');
const router = express.Router();

//? создание таска
router.post('/tasks', async (req, res) => {
  try {
    const { title, description, status, userId } = req.body;

    const newTask = new Task({ title, description, status, userId });
    await newTask.save();
    res.status(201).json(newTask);
  } catch (err) {
    res.status(500).json({ message: 'error', error: err });
  }
});

//? получение всех тасков
router.get('/tasks', async (req, res) => {
  try {
    const tasks = await Task.find();
    res.status(200).json(tasks);
  } catch (err) {
    res.status(500).json({ message: 'error', error: err });
  }
});

//? получение через id в Mongo
router.get('/tasks/:id', async (req, res) => {
  try {
    const task = await Task.findById(req.params.id);
    if (!task) {
      return res.status(404).json({ message: 'task not found' });
    }
    res.status(200).json(task);
  } catch (err) {
    res.status(500).json({ message: 'error', error: err });
  }
});

//? обновление задачи по  id
router.put('/tasks/:id', async (req, res) => {
  try {
    const { title, description, status } = req.body;
    const updatedTask = await Task.findByIdAndUpdate(
      req.params.id,
      { title, description, status },
      { new: true }
    );
    if (!updatedTask) {
      return res.status(404).json({ message: 'task not found' });
    }
    res.status(200).json(updatedTask);
  } catch (err) {
    res.status(500).json({ message: 'error', error: err });
  }
});

//? удаление  задачи по id
router.delete('/tasks/:id', async (req, res) => {
  try {
    const task = await Task.findByIdAndDelete(req.params.id);
    if (!task) {
      return res.status(404).json({ message: 'task not found' });
    }
    res.status(200).json({ message: 'task deleted' });
  } catch (err) {
    res.status(500).json({ message: 'error', error: err });
  }
});

module.exports = router;
