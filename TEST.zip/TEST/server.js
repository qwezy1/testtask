const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const routes = require('./routes/routes.js'); 

const app = express();
const PORT = 5000;

//? подключение к монго
const mongoURI = 'mongodb+srv://qwezy:mG7iikXpNo4s3OJq@cluster0.avsoe.mongodb.net/taskdb?retryWrites=true&w=majority';

mongoose.connect(mongoURI)
  .then(() => console.log('Connected to MongoDB Atlas'))
  .catch((err) => console.log('MongoDB connection error:', err));

//? для работы с JSON
app.use(bodyParser.json());

//? маршруты
app.use(routes);


app.listen(PORT, () => {
  console.log(`work on ${PORT}`);
});
